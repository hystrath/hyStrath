/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 1991-2007 OpenCFD Ltd.
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 2 of the License, or (at your
    option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

Description

\*---------------------------------------------------------------------------*/

#include "dsmcStickingDiffuseWallPatch2.H"
#include "addToRunTimeSelectionTable.H"
#include "fvc.H"

// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

namespace Foam
{

defineTypeNameAndDebug(dsmcStickingDiffuseWallPatch2, 0);

addToRunTimeSelectionTable
(
    dsmcPatchBoundary, 
    dsmcStickingDiffuseWallPatch2, 
    dictionary
);


// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //


// * * * * * * * * * * * Protected member functions  * * * * * * * * * * * * //

void dsmcStickingDiffuseWallPatch2::setProperties()
{
    dsmcDiffuseWallPatch::setProperties(); // NEW VINCENT

    //- read in the type ids
    const List<word> molecules (propsDict_.lookup("typeIds"));

    if(molecules.size() == 0)
    {
         FatalErrorIn("dsmcStickingDiffuseWallPatch2::setProperties()")
            << "Cannot have zero typeIds being adsorbed." << nl << "in: "
            << mesh_.time().system()/"boundariesDict"
            << exit(FatalError);
    }

    DynamicList<word> moleculesReduced(0);

    forAll(molecules, i)
    {
        const word& moleculeName(molecules[i]);

        if(findIndex(moleculesReduced, moleculeName) == -1)
        {
            moleculesReduced.append(moleculeName);
        }
    }

    moleculesReduced.shrink();

    //- set the type ids
    typeIds_.setSize(moleculesReduced.size(), -1);

    forAll(moleculesReduced, i)
    {
        const word& moleculeName(moleculesReduced[i]);

        const label typeId(findIndex(cloud_.typeIdList(), moleculeName));

        if(typeId == -1)
        {
            FatalErrorIn("dsmcStickingDiffuseWallPatch2::setProperties()")
                << "Cannot find typeId: " << moleculeName << nl << "in: "
                << mesh_.time().system()/"boundariesDict"
                << exit(FatalError);
        }

        typeIds_[i] = typeId;
    }
    
    adsorptionProbs_.clear();

    adsorptionProbs_.setSize(typeIds_.size(), 0.0);

    forAll(adsorptionProbs_, i)
    {
        adsorptionProbs_[i] = readScalar
        (
            propsDict_.subDict("adsorptionProbabilities")
                .lookup(moleculesReduced[i])
        );
    }
    
    residenceTime_.clear();

    residenceTime_.setSize(typeIds_.size(), 0.0);
    
    forAll(residenceTime_, i)
    {
        if (propsDict_.isDict("residenceTimes"))
        {
            residenceTime_[i] =
            (
                propsDict_.subDict("residenceTimes")
                    .lookupOrDefault<scalar>(moleculesReduced[i], GREAT)
            );
        }
        else
        {
            residenceTime_[i] = GREAT;
        }
    }
}


void dsmcStickingDiffuseWallPatch2::considerReleaseFromWall(dsmcParcel& p)
{ 
    //- Calculate probability this particle will be released
    const label& iD = p.typeId();
    
    const scalar deltaT = mesh_.time().deltaTValue();
    
    Random& rndGen = cloud_.rndGen();
    
    if(rndGen.scalar01() < deltaT/residenceTime_[iD])
    {
        const scalar mass = cloud_.constProps(iD).mass();
        
        vector& U = p.U();
        
        p.stuckToWall() = 0;
        
        U = sqrt
            (
                physicoChemical::k.value()
              * p.wallTemperature()[0]
              / mass
            )
          * (
                rndGen.GaussNormal()*p.wallVectors()[0]
              + rndGen.GaussNormal()*p.wallVectors()[1]
              - sqrt(-2.0*log(max(1 - rndGen.scalar01(), VSMALL)))
                    *p.wallVectors()[2]
            );


        // Update boundaryFluxMeasurements
        label wppIndex = p.wallTemperature()[1];
        const polyPatch& wpp = mesh_.boundaryMesh()[wppIndex];
        label wppLocalFace = p.wallTemperature()[2];
    
        const scalar fA = mag(wpp.faceAreas()[wppLocalFace]);
    
        vector nw = wpp.faceAreas()[wppLocalFace];
        nw /= mag(nw);
    
        scalar U_dot_nw = U & nw;
    
        vector Ut = U - U_dot_nw*nw;
    
        scalar invMagUnfA = 1/max(mag(U_dot_nw)*fA, VSMALL);

        cloud_.boundaryFluxMeasurements().rhoNBF()[iD][wppIndex][wppLocalFace] += invMagUnfA;
                            
        if(cloud_.constProps(iD).rotationalDegreesOfFreedom() > 0)
        {
            cloud_.boundaryFluxMeasurements().rhoNIntBF()[iD][wppIndex][wppLocalFace] += invMagUnfA; 
        }
        if(cloud_.constProps(iD).numberOfElectronicLevels() > 1)
        {
            cloud_.boundaryFluxMeasurements().rhoNElecBF()[iD][wppIndex][wppLocalFace] += invMagUnfA; 
        }
            
        cloud_.boundaryFluxMeasurements().rhoMBF()[iD][wppIndex][wppLocalFace] += mass*invMagUnfA;
        cloud_.boundaryFluxMeasurements().linearKEBF()[iD][wppIndex][wppLocalFace] += 0.5*mass
            *(U & U)*invMagUnfA;
        cloud_.boundaryFluxMeasurements().momentumBF()[iD][wppIndex][wppLocalFace] += mass*Ut*invMagUnfA;
        cloud_.boundaryFluxMeasurements().rotationalEBF()[iD][wppIndex][wppLocalFace] += p.ERot()*invMagUnfA;
        cloud_.boundaryFluxMeasurements().rotationalDofBF()[iD][wppIndex][wppLocalFace] += 
                cloud_.constProps(iD).rotationalDegreesOfFreedom()*invMagUnfA;
        
        forAll(p.vibLevel(), i)
        {
            cloud_.boundaryFluxMeasurements().vibrationalEBF()[iD][wppIndex][wppLocalFace] += 
                p.vibLevel()[i]*cloud_.constProps(iD).thetaV()[i]*physicoChemical::k.value()*invMagUnfA;
        }
        
        cloud_.boundaryFluxMeasurements().electronicEBF()[iD][wppIndex][wppLocalFace] += 
            cloud_.constProps(iD).electronicEnergyList()[p.ELevel()]*invMagUnfA;
        
        // post-interaction energy
        scalar postIE = 0.5*mass*(U & U) + p.ERot()
                + cloud_.constProps(iD).electronicEnergyList()[p.ELevel()];
        
        forAll(p.vibLevel(), i)
        {
            postIE += p.vibLevel()[i]*cloud_.constProps(iD).thetaV()[i]
                *physicoChemical::k.value();
        }
        
        // post-interaction momentum
        vector postIMom = mass*U;
        
        scalar preIE = p.wallTemperature()[3];
        vector preIMom = p.wallVectors()[3];
    
        scalar deltaQ = cloud_.nParticle()*(preIE - postIE)/(deltaT*fA);
        vector deltaFD = cloud_.nParticle()*(preIMom - postIMom)/(deltaT*fA);
        
        cloud_.boundaryFluxMeasurements().qBF()[iD][wppIndex][wppLocalFace] += deltaQ;
        cloud_.boundaryFluxMeasurements().fDBF()[iD][wppIndex][wppLocalFace] += deltaFD;
        
        p.wallTemperature()[0] = 0.0;
        p.wallVectors() = vector::zero;
    }
}


// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

// Construct from components
dsmcStickingDiffuseWallPatch2::dsmcStickingDiffuseWallPatch2
(
    Time& t,
    const polyMesh& mesh,
    dsmcCloud& cloud,
    const dictionary& dict
)
:
    dsmcPatchBoundary(t, mesh, cloud, dict), // MOD VINCE
    dsmcDiffuseWallPatch(t, mesh, cloud, dict),
    propsDict_(dict.subDict(dsmcDiffuseWallPatch::typeName + "Properties")
        .subDict("derivedWallPatchProperties")
        .subDict("stickingWallPatchProperties")),
    typeIds_(),
    adsorptionProbs_(),
    residenceTime_()
{
    writeInTimeDir_ = false;
    writeInCase_ = false;
    measurePropertiesAtWall_ = true;
    
    setProperties();
}


// * * * * * * * * * * * * * * * * Destructor  * * * * * * * * * * * * * * * //

dsmcStickingDiffuseWallPatch2::~dsmcStickingDiffuseWallPatch2()
{}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

void dsmcStickingDiffuseWallPatch2::initialConfiguration()
{}


void dsmcStickingDiffuseWallPatch2::calculateProperties()
{}


void dsmcStickingDiffuseWallPatch2::controlParticle
(
    dsmcParcel& p, 
    dsmcParcel::trackingData& td
)
{   
    const label& typeId = p.typeId();
    
    const label& iD = findIndex(typeIds_, typeId);
    
    label& stuckToWall = p.stuckToWall();
    
    if (stuckToWall != 1)
    {
        if(iD != -1) //- particle might be adsorbed
        {
            const scalar adsorbtionProbability = adsorptionProbs_[iD];
            
            Random& rndGen = cloud_.rndGen();
            
            if(adsorbtionProbability > rndGen.scalar01()) //- adsorbed
            {
                //- Particle becomes stuck to wall
                stuckToWall = 1;
        
                scalarField& wallTemperature = p.wallTemperature();
                
                vectorField& wallVectors = p.wallVectors();
                
                measurePropertiesBeforeControl(p);
                
                vector& U = p.U();

                scalar& ERot = p.ERot();
                
                // Wall unit normal vector and wall unit tangential vectors
                vector nw, tw1, tw2 = vector::zero;
                
                dsmcPatchBoundary::calculateWallUnitVectors(p, nw, tw1, tw2);

                scalar preIE = 0.0;
                vector preIMom = vector::zero;
                
                scalar mass = cloud_.constProps(typeId).mass();
                
                preIE = 0.5*mass*(U & U) + ERot + 
                    cloud_.constProps(typeId).electronicEnergyList()[p.ELevel()];
                
                forAll(p.vibLevel(), i)
                {
                    preIE += p.vibLevel()[i]
                        *cloud_.constProps(typeId).thetaV()[i]
                        *physicoChemical::k.value();
                }
                
                preIMom = mass*U;
                
                wallTemperature[3] = preIE;
                wallVectors[3] = preIMom;
                
                const scalar& T = getLocalTemperature(p.position()[depthAxis_]); // NEW VINCENT
                // const scalar& T = temperature_;
                
                U = SMALL*sqrt(physicoChemical::k.value()*T/mass)
                   *(
                        rndGen.GaussNormal()*tw1
                      + rndGen.GaussNormal()*tw2
                      - sqrt(-2.0*log(max(1 - rndGen.scalar01(), VSMALL)))*nw
                    );
                
                wallTemperature[0] = T; // NEW VINCENT
                //wallTemperature[0] = temperature_;
                
                label wppIndex = patchId_;
                const polyPatch& wpp = mesh_.boundaryMesh()[wppIndex];
                label wppLocalFace = wpp.whichFace(p.face());
                
                wallTemperature[1] = wppIndex;
                wallTemperature[2] = wppLocalFace;
                
                wallVectors[0] = tw1;
                wallVectors[1] = tw2;
                wallVectors[2] = nw;
            }
            else //- diffuse reflection
            {
                dsmcDiffuseWallPatch::controlParticle(p, td);
            }   
        }
        else //- otherwise, it is treated as a diffuse reflection
        {
            dsmcDiffuseWallPatch::controlParticle(p, td);
        }
    }
    
    // Separate loop as the particle may have been stuck just now
    if(stuckToWall == 1)
    {
        // If the particle is stuck, consider for release, i.e., desorption
        considerReleaseFromWall(p);
    }
}


void dsmcStickingDiffuseWallPatch2::output
(
    const fileName& fixedPathName,
    const fileName& timePath
)
{}


void dsmcStickingDiffuseWallPatch2::updateProperties(const dictionary& newDict)
{
    //- the main properties should be updated first
    updateBoundaryProperties(newDict);

    propsDict_ = newDict.subDict(dsmcDiffuseWallPatch::typeName + "Properties")
        .subDict("derivedWallPatchProperties")
        .subDict("stickingWallPatchProperties");

    setProperties();
}


} // End namespace Foam

// ************************************************************************* //
