/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 1991-2007 OpenCFD Ltd.
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.
    OpenFOAM is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 2 of the License, or (at your
    option) any later version.
    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.
    You should have received a copy of the GNU General Public License
    along with OpenFOAM; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
    
Description

\*---------------------------------------------------------------------------*/

#include "dsmcAbsorbingDiffuseWallPatch.H"
#include "addToRunTimeSelectionTable.H"
#include "fvc.H"

// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

namespace Foam
{

defineTypeNameAndDebug(dsmcAbsorbingDiffuseWallPatch, 0);

addToRunTimeSelectionTable
(
    dsmcPatchBoundary, 
    dsmcAbsorbingDiffuseWallPatch, 
    dictionary
);


// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

// Construct from components
dsmcAbsorbingDiffuseWallPatch::dsmcAbsorbingDiffuseWallPatch
(
    Time& t,
    const polyMesh& mesh,
    dsmcCloud& cloud,
    const dictionary& dict
)
:
    dsmcPatchBoundary(t, mesh, cloud, dict), // MOD VINCE
    dsmcDiffuseWallPatch(t, mesh, cloud, dict), // MOD VINCE
    propsDict_(dict.subDict(typeName + "Properties")),
    typeIds_(),
    absorptionProbs_()
{
    writeInTimeDir_ = false;
    writeInCase_ = false;
    measurePropertiesAtWall_ = true;
    
    setProperties();
}


// * * * * * * * * * * * * * * * * Destructor  * * * * * * * * * * * * * * * //

dsmcAbsorbingDiffuseWallPatch::~dsmcAbsorbingDiffuseWallPatch()
{}



// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

void dsmcAbsorbingDiffuseWallPatch::initialConfiguration()
{}


void dsmcAbsorbingDiffuseWallPatch::calculateProperties()
{}


void dsmcAbsorbingDiffuseWallPatch::controlParticle
(
    dsmcParcel& p, 
    dsmcParcel::trackingData& td
)
{
    measurePropertiesBeforeControl(p);
    
    Random& rndGen = cloud_.rndGen();
    
    const label& iD = findIndex(typeIds_, p.typeId());
    
    if(iD != -1) //- particle might be adsorbed
    {
        scalar absorptionProbability = absorptionProbs_[iD];
        
        if(absorptionProbability > rndGen.scalar01())
        {
             //- adsorbed, delete the particle
             td.keepParticle = false;
        }
        else
        {
            //- diffuse reflection
            dsmcDiffuseWallPatch::controlParticle(p, td);
        }   
    }
    else
    {
        //- otherwise, it is treated as a diffuse reflection
        dsmcDiffuseWallPatch::controlParticle(p, td);
    }
}


void dsmcAbsorbingDiffuseWallPatch::output
(
    const fileName& fixedPathName,
    const fileName& timePath
)
{}


void dsmcAbsorbingDiffuseWallPatch::updateProperties(const dictionary& newDict)
{
    //- the main properties should be updated first
    updateBoundaryProperties(newDict);

    propsDict_ = newDict.subDict(typeName + "Properties");

    setProperties();
}


void dsmcAbsorbingDiffuseWallPatch::setProperties()
{
    dsmcDiffuseWallPatch::setProperties(); // NEW VINCENT
    
    //  read in the type ids
    const List<word> molecules (propsDict_.lookup("typeIds"));

    if(molecules.size() == 0)
    {
        
        FatalErrorIn("dsmcAbsorbingDiffuseWallPatch::setProperties()")
            << "Cannot have zero typeIds being adsorbed." << nl << "in: "
            << mesh_.time().system()/"boundariesDict"
            << exit(FatalError);
    }

    DynamicList<word> moleculesReduced(0);

    forAll(molecules, i)
    {
        const word& moleculeName(molecules[i]);

        if(findIndex(moleculesReduced, moleculeName) == -1)
        {
            moleculesReduced.append(moleculeName);
        }
    }

    moleculesReduced.shrink();

    //  set the type ids
    typeIds_.setSize(moleculesReduced.size(), -1);

    forAll(moleculesReduced, i)
    {
        const word& moleculeName(moleculesReduced[i]);

        const label typeId(findIndex(cloud_.typeIdList(), moleculeName));

        if(typeId == -1)
        {
            FatalErrorIn("dsmcAbsorbingDiffuseWallPatch::setProperties()")
                << "Cannot find typeId: " << moleculeName << nl << "in: "
                << mesh_.time().system()/"boundariesDict"
                << exit(FatalError);
        }

        typeIds_[i] = typeId;
    }
    
    const dictionary& absorptionProbabilitiesDict
    (
        propsDict_.subDict("absorptionProbabilities")
    );
    
    absorptionProbs_.clear();

    absorptionProbs_.setSize(typeIds_.size(), 0.0);

    forAll(absorptionProbs_, i)
    {
        absorptionProbs_[i] = readScalar
        (
            absorptionProbabilitiesDict.lookup(moleculesReduced[i])
        );
    }
}


} // End namespace Foam

// ************************************************************************* //
