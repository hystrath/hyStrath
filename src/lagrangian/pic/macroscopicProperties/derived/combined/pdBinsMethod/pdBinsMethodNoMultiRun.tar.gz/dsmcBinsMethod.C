/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 1991-2007 OpenCFD Ltd.
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 2 of the License, or (at your
    option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

Description

\*---------------------------------------------------------------------------*/

#include "dsmcBinsMethod.H"
#include "addToRunTimeSelectionTable.H"
#include "graph.H"
// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

namespace Foam
{

defineTypeNameAndDebug(dsmcBinsMethod, 0);

addToRunTimeSelectionTable(dsmcField, dsmcBinsMethod, dictionary);



// * * * * * * * * * * * * * Private Member Functions  * * * * * * * * * * * //



// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

// Construct from components
dsmcBinsMethod::dsmcBinsMethod
(
    Time& t,
    const polyMesh& mesh,
    dsmcCloud& cloud,
    const dictionary& dict
)
:
    dsmcField(t, mesh, cloud, dict),
    propsDict_(dict.subDict(typeName + "Properties")),
//     fields_(t, mesh, "dummy"),
    regionName_(propsDict_.lookup("zoneName")),
    regionId_(-1),
    fieldName_(propsDict_.lookup("fieldName")),
    typeIds_(),

    averagingCounter_(0.0),
    
    mols_(),
    molsInt_(),
    mass_(),
    mcc_(),
    UCollected_(),
    rotationalEMean_(),
    rotationalDofMean_(),

    muu_(),
    muv_(),
    muw_(),
    mvv_(),
    mvw_(),
    mww_(),
    scalarPressure_(),
    mccu_(),
    mccv_(),
    mccw_(),

    eu_(),
    ev_(),
    ew_(),
    e_(),
    
    speciesMols_(),
    vibrationalETotal_(),
    vDof_(),
    mfp_(),

    N_(),
    rhoN_(),
    rhoM_(),
    UMean_(),
    translationalTemperature_(),
    rotationalTemperature_(),
    vibrationalTemperature_(),
    overallTemperature_(),
    
    pField_(),
    tauField_(),
    qField_(),
    meanFreePath_(),
    
    outputField_(4, true)
    
{
    const cellZoneMesh& cellZones = mesh_.cellZones();

    regionId_ = cellZones.findZoneID(regionName_);

    if(regionId_ == -1)
    {
        FatalErrorIn("dsmcBinsMethod::dsmcBinsMethod()")
            << "Cannot find region: " << regionName_ << nl << "in: "
            << time_.time().system()/"fieldPropertiesDict"
            << exit(FatalError);
    }

    // standard to reading typeIds ------------ 
    const List<word> molecules (propsDict_.lookup("typeIds"));

    DynamicList<word> moleculesReduced(0);

    forAll(molecules, i)
    {
        const word& moleculeName(molecules[i]);

        if(findIndex(moleculesReduced, moleculeName) == -1)
        {
            moleculesReduced.append(moleculeName);
        }
    }

    moleculesReduced.shrink();

    typeIds_.setSize(moleculesReduced.size(), -1);

    forAll(moleculesReduced, i)
    {
        const word& moleculeName(moleculesReduced[i]);

        label typeId(findIndex(cloud_.typeIdList(), moleculeName));

        if(typeId == -1)
        {
            FatalErrorIn("dsmcInflowPatch::dsmcInflowPatch()")
                << "Cannot find typeId: " << moleculeName << nl << "in: "
                << t.system()/"boundariesDict"
                << exit(FatalError);
        }

        typeIds_[i] = typeId;
    }
    
    // ---------------------------------------------------

    // create bin model
    binModel_ = autoPtr<binModel>
    (
        binModel::New(mesh, propsDict_)
    );
    
    const label& nBins = binModel_->nBins();

    mols_.setSize(nBins, 0.0);
    molsInt_.setSize(nBins, 0.0);
    mass_.setSize(nBins, 0.0);
    mcc_.setSize(nBins, 0.0);
    mom_.setSize(nBins, vector::zero);
    UCollected_.setSize(nBins, vector::zero);
    rotationalEMean_.setSize(nBins, 0.0);
    rotationalDofMean_.setSize(nBins, 0.0);  

    muu_.setSize(nBins, 0.0);
    muv_.setSize(nBins, 0.0);
    muw_.setSize(nBins, 0.0);
    mvv_.setSize(nBins, 0.0);
    mvw_.setSize(nBins, 0.0);
    mww_.setSize(nBins, 0.0);
    scalarPressure_.setSize(nBins, 0.0);
    mccu_.setSize(nBins, 0.0);
    mccv_.setSize(nBins, 0.0);
    mccw_.setSize(nBins, 0.0);

    eu_.setSize(nBins, 0.0);
    ev_.setSize(nBins, 0.0);
    ew_.setSize(nBins, 0.0);
    e_.setSize(nBins, 0.0);
    
    vibrationalETotal_.setSize(nBins);
    speciesMols_.setSize(nBins);
    vDof_.setSize(nBins);
    mfp_.setSize(nBins);
    
    N_.setSize(nBins, 0.0);
    rhoN_.setSize(nBins, 0.0);
    rhoM_.setSize(nBins, 0.0);
    UMean_.setSize(nBins, vector::zero);
    UCAM_.setSize(nBins, vector::zero);    
    translationalTemperature_.setSize(nBins, 0.0);
    rotationalTemperature_.setSize(nBins, 0.0);
    vibrationalTemperature_.setSize(nBins, 0.0);
    overallTemperature_.setSize(nBins, 0.0);
    
    pField_.setSize(nBins, tensor::zero);
    tauField_.setSize(nBins, tensor::zero);
    qField_.setSize(nBins, vector::zero);
    meanFreePath_.setSize(nBins, 0.0);
    Ma_.setSize(nBins, 0.0);
    
    // outer list is the bins, inner list is type ids
    forAll(vibrationalETotal_, b)
    {
        vibrationalETotal_[b].setSize(typeIds_.size(), 0.0);    
        speciesMols_[b].setSize(typeIds_.size(), 0.0);
        vDof_[b].setSize(typeIds_.size(), 0.0);
        mfp_[b].setSize(typeIds_.size(), 0.0);
    } 

    
    // choice of measurement property to output

    if (propsDict_.found("outputProperties"))
    {

        const List<word> measurements (propsDict_.lookup("outputProperties"));

        DynamicList<word> propertyNames(0);

        forAll(measurements, i)
        {
            const word& propertyName(measurements[i]);
    
            if(findIndex(propertyNames, propertyName) == -1)
            {
                propertyNames.append(propertyName);
            }
        }

        propertyNames.shrink();

        if(findIndex(propertyNames, "density") == -1)
        {
            outputField_[0] = false;
        }

        if(findIndex(propertyNames, "velocity") == -1)
        {
            outputField_[1] = false;
        }

        if(findIndex(propertyNames, "temperature") == -1)
        {
            outputField_[2] = false;
        }

        if(findIndex(propertyNames, "pressure") == -1)
        {
            outputField_[3] = false;
        }

        // check for user:
        forAll(propertyNames, i)
        {
            const word& propertyName(propertyNames[i]);

            if
            (
                (propertyName != "density") &&
                (propertyName != "velocity") &&
                (propertyName != "temperature") &&
                (propertyName != "pressure")
            )
            {    
                FatalErrorIn("dsmcBinsMethod::dsmcBinsMethod()")
                    << "Cannot find measurement property: " << propertyName
                    << nl << "in: "
                    << time_.time().system()/"fieldPropertiesDict"
                    << exit(FatalError);            
            }
        }
    }    
}


// * * * * * * * * * * * * * * * * Destructor  * * * * * * * * * * * * * * * //

dsmcBinsMethod::~dsmcBinsMethod()
{}

// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

void dsmcBinsMethod::createField()
{  
}


void dsmcBinsMethod::calculateField()
{
    averagingCounter_ += 1.0;
      
    const List< DynamicList<dsmcParcel*> >& cellOccupancy
            = cloud_.cellOccupancy();
            
    const labelList& cells = mesh_.cellZones()[regionId_];

    forAll(cells, c)
    {
        const label& cellI = cells[c];
        
        const List<dsmcParcel*>& molsInCell = cellOccupancy[cellI];

        forAll(molsInCell, mIC)
        {
            dsmcParcel* p = molsInCell[mIC];
            
            label iD = findIndex(typeIds_, p->typeId());

            const vector& rI = p->position();

            label n = binModel_->isPointWithinBin(rI, cellI);

            if(n != -1)
            {
                if(iD != -1)
                {
                    const dsmcParcel::constantProperties& constProp 
                                    = cloud_.constProps(p->typeId());
                                    
                    const scalar& rotationalDof = 
                        cloud_.constProps(p->typeId()).rotationalDegreesOfFreedom();
                        
                    const scalar& mass = constProp.mass()*cloud_.nParticle();

                    mols_[n] += 1.0;
                    mass_[n] += mass;
                    mcc_[n] += mass*mag(p->U())*mag(p->U());                   
                    UCollected_[n] += p->U();
                    mom_[n] += mass*p->U();
                    rotationalEMean_[n] += p->ERot();
                    rotationalDofMean_[n] += rotationalDof;
                    
                    muu_[n] += mass*sqr(p->U().x());
                    muv_[n] += mass*( (p->U().x()) * (p->U().y()) );
                    muw_[n] += mass*( (p->U().x()) * (p->U().z()) );
                    mvv_[n] += mass*sqr(p->U().y());
                    mvw_[n] += mass*( (p->U().y()) * (p->U().z()) );
                    mww_[n] += mass*sqr(p->U().z());
                    mccu_[n] += mass*mag(p->U())*mag(p->U())*(p->U().x());
                    mccv_[n] += mass*mag(p->U())*mag(p->U())*(p->U().y());
                    mccw_[n] += mass*mag(p->U())*mag(p->U())*(p->U().z());

                    eu_[n] += cloud_.nParticle()*( p->ERot() + p->EVib() )*(p->U().x());
                    ev_[n] += cloud_.nParticle()*( p->ERot() + p->EVib() )*(p->U().y());
                    ew_[n] += cloud_.nParticle()*( p->ERot() + p->EVib() )*(p->U().z());
                    e_[n] += cloud_.nParticle()*( p->ERot() + p->EVib() );

                    vibrationalETotal_[n][iD] += p->EVib();
                    speciesMols_[n][iD] += 1.0;
                    
                    if(rotationalDof > VSMALL)
                    {
                        molsInt_[n] += 1.0;
                    }
                }
            }
        }
    }
 
    if(time_.averagingTime())
    {
        scalarField mass = mass_;
        scalarField molsInt = molsInt_;
        scalarField mols = mols_;
        scalarField mcc = mcc_;
        vectorField mom = mom_;
        vectorField UCollected = UCollected_;
        scalarField rotationalEMean = rotationalEMean_;
        scalarField rotationalDofMean = rotationalDofMean_;

        scalarField muu = muu_;
        scalarField muv = muv_;
        scalarField muw = muw_;
        scalarField mvv = mvv_;
        scalarField mvw = mvw_;
        scalarField mww = mww_;
        scalarField mccu = mccu_;
        scalarField mccv = mccv_;
        scalarField mccw = mccw_;

        scalarField eu = eu_;
        scalarField ev = ev_;
        scalarField ew = ew_;
        scalarField e = e_;
        
        List<scalarField> vibrationalETotal = vibrationalETotal_;
        List<scalarField> speciesMols = speciesMols_;
        
        //- parallel communication

        if(Pstream::parRun())
        {
            forAll(mols, n)
            {
                reduce(mols[n], sumOp<scalar>());
                reduce(molsInt[n], sumOp<scalar>());
                reduce(mass[n], sumOp<scalar>());
                reduce(mcc[n], sumOp<scalar>());
                reduce(mom[n], sumOp<vector>());                
                reduce(UCollected[n], sumOp<vector>());
                reduce(rotationalEMean[n], sumOp<scalar>());
                reduce(rotationalDofMean[n], sumOp<scalar>());
                
                reduce(muu[n], sumOp<scalar>());
                reduce(muv[n], sumOp<scalar>());
                reduce(muw[n], sumOp<scalar>());
                reduce(mvv[n], sumOp<scalar>());
                reduce(mvw[n], sumOp<scalar>());
                reduce(mww[n], sumOp<scalar>());
                reduce(mccu[n], sumOp<scalar>());
                reduce(mccv[n], sumOp<scalar>());
                reduce(mccw[n], sumOp<scalar>());

                reduce(eu[n], sumOp<scalar>());
                reduce(ev[n], sumOp<scalar>());
                reduce(ew[n], sumOp<scalar>());
                reduce(e[n], sumOp<scalar>());
            }
            
            forAll(vibrationalETotal, b)
            {
                forAll(vibrationalETotal[b], n)
                {
                    reduce(vibrationalETotal[b][n], sumOp<scalar>());
                    reduce(speciesMols[b][n], sumOp<scalar>());
                }
            }
        }

        forAll(mols, n)
        {
            scalar volume = binModel_->binVolume(n);

            N_[n] = mols[n]/averagingCounter_;
            rhoN_[n] = (mols[n]*cloud_.nParticle())/(averagingCounter_*volume);
            rhoM_[n] = mass[n]/(averagingCounter_*volume);
            
            if(mols[n] > 0.0)
            {
                UMean_[n] = UCollected[n]/mols[n];
                
                UCAM_[n] = mom[n]/mass[n];
                
                translationalTemperature_[n] = (1.0/(3.0*physicoChemical::k.value()))
                                                *(
                                                    ((mcc[n]/(mols[n]*cloud_.nParticle())))
                                                    - (
                                                        (mass[n]/(mols[n]*cloud_.nParticle())
                                                      )*mag(UMean_[n])*mag(UMean_[n]))
                                                );
                                                
                if(rotationalDofMean[n] > VSMALL)
                {
                    rotationalTemperature_[n] = (2.0/physicoChemical::k.value())*(rotationalEMean[n]/rotationalDofMean[n]);
                }
                else
                {
                    rotationalTemperature_[n] = 0.0;
                }

                tensorField p(mols.size(), tensor::zero);

                p[n].xx() = rhoN_[n]*( muu[n]/(mols[n]*cloud_.nParticle()) - ((mass[n]/(mols[n]*cloud_.nParticle()))*UMean_[n].x()*UMean_[n].x()) );
                p[n].xy() = rhoN_[n]*( muv[n]/(mols[n]*cloud_.nParticle()) - ((mass[n]/(mols[n]*cloud_.nParticle()))*UMean_[n].x()*UMean_[n].y()) );
                p[n].xz() = rhoN_[n]*( muw[n]/(mols[n]*cloud_.nParticle()) - ((mass[n]/(mols[n]*cloud_.nParticle()))*UMean_[n].x()*UMean_[n].z()) );
                p[n].yx() = p[n].xy();
                p[n].yy() = rhoN_[n]*( mvv[n]/(mols[n]*cloud_.nParticle()) - ((mass[n]/(mols[n]*cloud_.nParticle()))*UMean_[n].y()*UMean_[n].y()) );
                p[n].yz() = rhoN_[n]*( mvw[n]/(mols[n]*cloud_.nParticle()) - ((mass[n]/(mols[n]*cloud_.nParticle()))*UMean_[n].y()*UMean_[n].z()) );
                p[n].zx() = p[n].xz();
                p[n].zy() = p[n].yz();
                p[n].zz() = rhoN_[n]*(mww[n]/(mols[n]*cloud_.nParticle()) - ((mass[n]/(mols[n]*cloud_.nParticle()))*UMean_[n].z()*UMean_[n].z()));
                
                pField_[n] = p[n];

                scalarPressure_[n] = (1.0/3.0)*(p[n].xx() + p[n].yy() + p[n].zz());
                                        
                // make reference 
                tensorField tau(mols.size(), tensor::zero); 
                
                tau[n] = -p[n];
                tau[n].xx() += scalarPressure_[n];
                tau[n].yy() += scalarPressure_[n];
                tau[n].zz() += scalarPressure_[n];
                tauField_[n] = tau[n];
                
                vectorField q(mols_.size(), vector::zero);
                
                q[n].x() = rhoN_[n]*(
                                        0.5*(mccu[n]/(mols[n]*cloud_.nParticle()))
                                        - 0.5*(mcc[n]/(mols[n]*cloud_.nParticle()))*UMean_[n].x()
                                        + eu[n]/(mols[n]*cloud_.nParticle())
                                        - (e[n]/(mols[n]*cloud_.nParticle()))*UMean_[n].x()
                                  )
                                        - p[n].xx()*UMean_[n].x()
                                        - p[n].xy()*UMean_[n].y()
                                        - p[n].xz()*UMean_[n].z();
                                        
                 //terms involving pressure tensor should not be multiplied by the number density (see Bird corrigendum)
                
                
                q[n].y() = rhoN_[n]*(
                                        0.5*(mccv[n]/(mols[n]*cloud_.nParticle()))
                                        - 0.5*(mcc[n]/(mols[n]*cloud_.nParticle()))*UMean_[n].y()
                                        + ev[n]/(mols[n]*cloud_.nParticle())
                                        - (e[n]/(mols[n]*cloud_.nParticle()))*UMean_[n].y()
                                  )
                                        - p[n].yx()*UMean_[n].x()
                                        - p[n].yy()*UMean_[n].y()
                                        - p[n].yz()*UMean_[n].z();
                
                q[n].z() = rhoN_[n]*(
                                        0.5*(mccw[n]/(mols[n]*cloud_.nParticle()))
                                        - 0.5*(mcc[n]/(mols[n]*cloud_.nParticle()))*UMean_[n].z()
                                        + ew[n]/(mols[n]*cloud_.nParticle())
                                        - (e[n]/(mols[n]*cloud_.nParticle()))*UMean_[n].z()
                                  )
                                        - p[n].zx()*UMean_[n].x()
                                        - p[n].zy()*UMean_[n].y()
                                        - p[n].zz()*UMean_[n].z();
                
                qField_[n] = q[n];
                
                const label& nBins = binModel_->nBins();
                
                // vibrational temperature
//                 scalarField vibTxvDof;
                scalarField totalvDof(nBins, 0.0);
                scalarField vibT(nBins, 0.0);
                
//                 vibTxvDof.setSize(nBins, 0.0);
//                 totalvDof.setSize(nBins, 0.0);
                
                forAll(vibrationalETotal[n], iD)
                {
                    if(vibrationalETotal[n][iD] > VSMALL && speciesMols[n][iD] > VSMALL)
                    {        
                        const scalar& thetaV = cloud_.constProps(typeIds_[iD]).thetaV();
                        
                        scalar vibrationalEMean = (vibrationalETotal[n][iD]/speciesMols[n][iD]);
                        
                        scalar iMean = vibrationalEMean/(physicoChemical::k.value()*thetaV);
                        
                        scalar fraction = speciesMols[n][iD]/molsInt[n];
                        
                        scalar vibTID = thetaV / log(1.0 + (1.0/iMean));
                        
                        scalar vDof = fraction*(2.0*thetaV/vibTID) / (exp(thetaV/vibTID) - 1.0);
                        
//                         vibTxvDof[n] += vibT*vDof;
                        
                        totalvDof[n] += vDof;
                        
                        vibT[n] += vibTID*fraction;
                    }
                }
                
//                 if(totalvDof[n] > VSMALL)
//                 {
                    vibrationalTemperature_[n] = vibT[n];
//                 }
                
                //overallTemperature
        
                scalar nRotDof = 0.0;
                    
                if(mols[n] > VSMALL)
                {
                    nRotDof = rotationalDofMean[n] / mols[n];
                }
                
//                 scalar totalDof = 0.0;
//                 label averageCounter = 0;
//                 
//                 forAll(vDof_[n], iD)
//                 {
//                     if(vDof_[n][iD] > VSMALL)
//                     {
//                         totalDof += vDof_[n][iD];
//                         averageCounter++;
//                     }
//                 }
//                 
//                 scalar averagevDof = 0.0;
//                 
//                 if(averageCounter > VSMALL)
//                 {
//                     averagevDof = totalDof/averageCounter;
//                 }
                
                overallTemperature_[n] = ( 
                                        (3.0*translationalTemperature_[n]) 
                                        + (nRotDof*rotationalTemperature_[n]) 
                                        + (totalvDof[n]*vibrationalTemperature_[n])
                                    ) /
                                    (3.0 + nRotDof + totalvDof[n]);
                                    
                forAll(mfp_[n], iD)
                {
                    label qspec = 0;
                    
                    //scalar d1 = sqrt(sqrt()/96.0*referenceViscosity)
                    
                    for (qspec=0; qspec<typeIds_.size(); qspec++)
                    {
                        scalar dPQ = 0.5*(cloud_.constProps(typeIds_[iD]).d() + cloud_.constProps(typeIds_[qspec]).d());
                        scalar omegaPQ = 0.5*(cloud_.constProps(typeIds_[iD]).omega() + cloud_.constProps(typeIds_[qspec]).omega());
                        scalar massRatio = cloud_.constProps(typeIds_[iD]).mass()/cloud_.constProps(typeIds_[qspec]).mass();
                        
                        if(speciesMols[n][qspec] > VSMALL && translationalTemperature_[n] > VSMALL)
                        {
                            scalar nDensQ = (cloud_.nParticle()*speciesMols[n][qspec])/(volume*averagingCounter_);
                            
                            mfp_[n][iD] += (pi*dPQ*dPQ*nDensQ*pow(273.0/translationalTemperature_[n],omegaPQ-0.5)*sqrt(1.0+massRatio)); //Bird, eq (4.76)
                        }
                    }
                    
                    if(mfp_[n][iD] > VSMALL)
                    {
                        mfp_[n][iD] = 1.0/mfp_[n][iD];
                    }
                }
                
//                 forAll(meanFreePath_, n)
//                 {
                    meanFreePath_[n] = 0.0;
//                 }
                               
                forAll(mfp_[n], iD)
                {
                    if(rhoN_[n] > VSMALL)
                    {                        
                        scalar nDensP = (cloud_.nParticle()*speciesMols[n][iD])/(volume*averagingCounter_);
                        
                        meanFreePath_[n] += mfp_[n][iD]*nDensP/rhoN_[n]; //Bird, eq (4.77)
                    }
                    else
                    {
                        meanFreePath_[n] = GREAT;
                    }
                }
                
                mfp_[n] = scalar(0.0);
                
                scalar molecularMass = 0.0;
                scalar molarconstantPressureSpecificHeat = 0.0;
                scalar molarconstantVolumeSpecificHeat = 0.0;
                scalar gasConstant = 0.0;
                scalar gamma = 0.0;
                scalar speedOfSound = 0.0;
                
                forAll(mfp_[n], iD)  
                {
                    const label& typeId = typeIds_[iD];

                    if(rhoN_[n] > VSMALL)
                    {
                        molecularMass += cloud_.constProps(typeId).mass()*(speciesMols[n][iD]/mols[n]);
                        molarconstantPressureSpecificHeat += (5.0 + cloud_.constProps(typeId).rotationalDegreesOfFreedom())*(speciesMols[n][iD]/mols[n]);
                        molarconstantVolumeSpecificHeat += (3.0 + cloud_.constProps(typeId).rotationalDegreesOfFreedom())*(speciesMols[n][iD]/mols[n]);
                    }
                } 

//                 forAll(molarconstantPressureSpecificHeat, n)
//                 {
//                     scalar gasConstant = 0.0;
//                     scalar gamma = 0.0;
//                     scalar speedOfSound = 0.0;

//                     Info << "n = " << n << endl;
//                     Info << "molecularMass[n] = " << molecularMass[n] << endl;
//                     Info << "gasConstant[n] = " << gasConstant[n] << endl;
//                     Info << "molarconstantVolumeSpecificHeat[n] = " << molarconstantVolumeSpecificHeat[n] << endl;
                    
                    if(molecularMass > VSMALL)
                    {
                        gasConstant = physicoChemical::k.value()/molecularMass; // R = k/m
                    }

                    if(molarconstantVolumeSpecificHeat > VSMALL)
                    {
                        gamma = molarconstantPressureSpecificHeat/molarconstantVolumeSpecificHeat; // gamma = cP/cV
                    }
                    
                    if(translationalTemperature_[n] > VSMALL && gamma > VSMALL && gasConstant > VSMALL)
                    {
                        speedOfSound = sqrt(gamma*gasConstant*translationalTemperature_[n]);
                    }
                
                    if(speedOfSound > VSMALL)
                    {
                        Ma_[n] = mag(UMean_[n])/speedOfSound;
                    }
                    else
                    {
                        Ma_[n] = 0.0;
                    }
//                 }
            }
        }

        if(time_.resetFieldsAtOutput())
        {
            //- reset fields
            averagingCounter_ = 0.0;
            
            mols_ = 0.0;
            molsInt_ = 0.0;
            mass_ = 0.0;
            mcc_ = 0.0;
            mom_ = vector::zero;
            UCollected_ = vector::zero;
            rotationalEMean_ = 0.0;
            rotationalDofMean_ = 0.0;
            
            muu_ = 0.0;
            muv_ = 0.0;
            muw_ = 0.0;
            mvv_ = 0.0;
            mvw_ = 0.0;
            mww_ = 0.0;
            mccu_ = 0.0;
            mccv_ = 0.0;
            mccw_ = 0.0;
            mcc_ = 0.0;
            eu_ = 0.0;
            ev_ = 0.0;
            ew_ = 0.0;
            e_ = 0.0;            
        }
    }
}

void dsmcBinsMethod::writeField()
{
    const Time& runTime = time_.time();

    if(runTime.outputTime())
    {
        if(Pstream::master())
        {
            scalarField bins = binModel_->binPositions();
            vectorField vectorBins = binModel_->bins();

            // output densities
            if(outputField_[0])
            {
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_N.xy",
                    bins,
                    N_
                );
    
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_N_3D_pos.xy",
                    vectorBins,
                    N_
                );
    
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_rhoN.xy",
                    bins,
                    rhoN_
                );
    
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_rhoN_3D_pos.xy",
                    vectorBins,
                    rhoN_
                );
    
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_rhoM.xy",
                    bins,
                    rhoM_
                );
    
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_rhoM_3D_pos.xy",
                    vectorBins,
                    rhoM_
                );
            }

            // output velocities
            if(outputField_[1])
            {
                
                
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_U_SAM.xyz",
                    bins,
                    UMean_
                );
    
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_U_SAM_3D_pos.xyz",
                    vectorBins,
                    UMean_
                );    

                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_U_CAM.xyz",
                    bins,
                    UCAM_
                );
    
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_U_CAM_3D_pos.xyz",
                    vectorBins,
                    UCAM_
                );   
            }

            // output temperature
            if(outputField_[2])
            {
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_translationalTemperature.xy",
                    bins,
                    translationalTemperature_
                );
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_translationalTemperature_3D_pos.xyz",
                    vectorBins,
                    translationalTemperature_
                );                
                
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_rotationalTemperature.xy",
                    bins,
                    rotationalTemperature_
                );
                
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_rotationalTemperature_3D_pos.xyz",
                    vectorBins,
                    rotationalTemperature_
                );                
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_vibrationalTemperature.xy",
                    bins,
                    vibrationalTemperature_
                );
                
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_vibrationalTemperature_3D_pos.xyz",
                    vectorBins,
                    vibrationalTemperature_
                );
                
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_overallTemperature.xy",
                    bins,
                    overallTemperature_
                );
                
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_overallTemperature_3D_pos.xyz",
                    vectorBins,
                    overallTemperature_
                ); 
            }

            // output pressure
            if(outputField_[3])
            {
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_pressureTensor.xyz",
                    bins,
                    pField_
                );
    
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_pressureTensor_3D_pos.xyz",
                    vectorBins,
                    pField_
                );

                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_p.xy",
                    bins,
                    scalarPressure_
                );
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_p_3D_pos.xyz",
                    vectorBins,
                    scalarPressure_
                );
                
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_stressTensor.xyz",
                    bins,
                    tauField_
                );

                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_stressTensor_3D_pos.xyz",
                    vectorBins,
                    tauField_
                );
                
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_heatFluxVector.xyz",
                    bins,
                    qField_
                );

                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_heatFluxVector_3D_pos.xyz",
                    vectorBins,
                    qField_
                );  
                
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_variableHardSphereMeanFreePath.xy",
                    bins,
                    meanFreePath_
                );
                
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_variableHardSphereMeanFreePath_3D_pos.xyz",
                    vectorBins,
                    meanFreePath_
                );
                
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_Ma.xy",
                    bins,
                    Ma_
                );
                
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_Ma_3D_pos.xyz",
                    vectorBins,
                    Ma_
                );
            }
        }
    }
}

void dsmcBinsMethod::updateProperties(const dictionary& newDict)
{
    //- the main properties should be updated first
    updateBasicFieldProperties(newDict);

}


} // End namespace Foam

// ************************************************************************* //
