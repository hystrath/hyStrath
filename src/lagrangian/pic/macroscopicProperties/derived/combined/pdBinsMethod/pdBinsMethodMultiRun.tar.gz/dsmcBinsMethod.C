/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 1991-2007 OpenCFD Ltd.
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 2 of the License, or (at your
    option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

Description

\*---------------------------------------------------------------------------*/

#include "dsmcBinsMethod.H"
#include "addToRunTimeSelectionTable.H"
#include "graph.H"
// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

namespace Foam
{

defineTypeNameAndDebug(dsmcBinsMethod, 0);

addToRunTimeSelectionTable(dsmcField, dsmcBinsMethod, dictionary);



// * * * * * * * * * * * * * Private Member Functions  * * * * * * * * * * * //



// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

// Construct from components
dsmcBinsMethod::dsmcBinsMethod
(
    Time& t,
    const polyMesh& mesh,
    dsmcCloud& cloud,
    const dictionary& dict
)
:
    dsmcField(t, mesh, cloud, dict),
    propsDict_(dict.subDict(typeName + "Properties")),
//     fields_(t, mesh, "dummy"),
    regionName_(propsDict_.lookup("zoneName")),
    regionId_(-1),
    fieldName_(propsDict_.lookup("fieldName")),
    typeIds_(),

    averagingCounter_(0.0),
    
    mols_(),
    mass_(),
    mcc_(),
    UCollected_(),
    rotationalEMean_(),
    rotationalDofMean_(),

    muu_(),
    muv_(),
    muw_(),
    mvv_(),
    mvw_(),
    mww_(),
    mccu_(),
    mccv_(),
    mccw_(),

    eu_(),
    ev_(),
    ew_(),
    e_(),

    N_(),
    rhoN_(),
    rhoM_(),
    UMean_(),
    translationalTemperature_(),
    rotationalTemperature_(),
    vibrationalTemperature_(),
    overallTemperature_(),
    
    pField_(),
    tauField_(),
    qField_(),
    
    outputField_(4, true),
    averagingAcrossManyRuns_(false)
{
    const cellZoneMesh& cellZones = mesh_.cellZones();

    regionId_ = cellZones.findZoneID(regionName_);

    if(regionId_ == -1)
    {
        FatalErrorIn("dsmcBinsMethod::dsmcBinsMethod()")
            << "Cannot find region: " << regionName_ << nl << "in: "
            << time_.time().system()/"fieldPropertiesDict"
            << exit(FatalError);
    }

    // standard to reading typeIds ------------ 
    const List<word> molecules (propsDict_.lookup("typeIds"));

    DynamicList<word> moleculesReduced(0);

    forAll(molecules, i)
    {
        const word& moleculeName(molecules[i]);

        if(findIndex(moleculesReduced, moleculeName) == -1)
        {
            moleculesReduced.append(moleculeName);
        }
    }

    moleculesReduced.shrink();

    typeIds_.setSize(moleculesReduced.size(), -1);

    forAll(moleculesReduced, i)
    {
        const word& moleculeName(moleculesReduced[i]);

        label typeId(findIndex(cloud_.typeIdList(), moleculeName));

        if(typeId == -1)
        {
            FatalErrorIn("dsmcInflowPatch::dsmcInflowPatch()")
                << "Cannot find typeId: " << moleculeName << nl << "in: "
                << t.system()/"boundariesDict"
                << exit(FatalError);
        }

        typeIds_[i] = typeId;
    }
    
    // ---------------------------------------------------

    // create bin model
    binModel_ = autoPtr<binModel>
    (
        binModel::New(mesh, propsDict_)
    );
    
    const label& nBins = binModel_->nBins();

    mols_.setSize(nBins, 0.0);
    mass_.setSize(nBins, 0.0);
    mcc_.setSize(nBins, 0.0);
    mom_.setSize(nBins, vector::zero);
    UCollected_.setSize(nBins, vector::zero);
    rotationalEMean_.setSize(nBins, 0.0);
    rotationalDofMean_.setSize(nBins, 0.0);  

    muu_.setSize(nBins, 0.0);
    muv_.setSize(nBins, 0.0);
    muw_.setSize(nBins, 0.0);
    mvv_.setSize(nBins, 0.0);
    mvw_.setSize(nBins, 0.0);
    mww_.setSize(nBins, 0.0);
    mccu_.setSize(nBins, 0.0);
    mccv_.setSize(nBins, 0.0);
    mccw_.setSize(nBins, 0.0);

    eu_.setSize(nBins, 0.0);
    ev_.setSize(nBins, 0.0);
    ew_.setSize(nBins, 0.0);
    e_.setSize(nBins, 0.0);
    
    N_.setSize(nBins, 0.0);
    rhoN_.setSize(nBins, 0.0);
    rhoM_.setSize(nBins, 0.0);
    UMean_.setSize(nBins, vector::zero);
    UCAM_.setSize(nBins, vector::zero);    
    translationalTemperature_.setSize(nBins, 0.0);
    rotationalTemperature_.setSize(nBins, 0.0);
    vibrationalTemperature_.setSize(nBins, 0.0);
    overallTemperature_.setSize(nBins, 0.0);
    
    scalarPressure_.setSize(nBins, 0.0);
    pField_.setSize(nBins, tensor::zero);
    tauField_.setSize(nBins, tensor::zero);
    qField_.setSize(nBins, vector::zero);
    
    nBins_ = nBins;
    
    if (propsDict_.found("averagingAcrossManyRuns"))
    {
        averagingAcrossManyRuns_ = Switch(propsDict_.lookup("averagingAcrossManyRuns"));
        
        // read in stored data from dictionary
        if(averagingAcrossManyRuns_)
        {
            Info << nl << " Averaging across many runs initiated." << endl;

            readIn();
        }         
    }
    
    const scalar& deltaT = time_.mdTimeInterval().deltaT();
    scalar writeInterval = readScalar(t.controlDict().lookup("writeInterval"));
    deltaT_ = deltaT;
    measuringTime_ = writeInterval;
    runningTime_ = 0.0;   

    
    // choice of measurement property to output

    if (propsDict_.found("outputProperties"))
    {

        const List<word> measurements (propsDict_.lookup("outputProperties"));

        DynamicList<word> propertyNames(0);

        forAll(measurements, i)
        {
            const word& propertyName(measurements[i]);
    
            if(findIndex(propertyNames, propertyName) == -1)
            {
                propertyNames.append(propertyName);
            }
        }

        propertyNames.shrink();

        if(findIndex(propertyNames, "density") == -1)
        {
            outputField_[0] = false;
        }

        if(findIndex(propertyNames, "velocity") == -1)
        {
            outputField_[1] = false;
        }

        if(findIndex(propertyNames, "temperature") == -1)
        {
            outputField_[2] = false;
        }

        if(findIndex(propertyNames, "pressure") == -1)
        {
            outputField_[3] = false;
        }

        // check for user:
        forAll(propertyNames, i)
        {
            const word& propertyName(propertyNames[i]);

            if
            (
                (propertyName != "density") &&
                (propertyName != "velocity") &&
                (propertyName != "temperature") &&
                (propertyName != "pressure")
            )
            {    
                FatalErrorIn("dsmcBinsMethod::dsmcBinsMethod()")
                    << "Cannot find measurement property: " << propertyName
                    << nl << "in: "
                    << time_.time().system()/"fieldPropertiesDict"
                    << exit(FatalError);            
            }
        }
    }    
}


// * * * * * * * * * * * * * * * * Destructor  * * * * * * * * * * * * * * * //

dsmcBinsMethod::~dsmcBinsMethod()
{}

// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

void dsmcBinsMethod::readIn()
{
    IOdictionary dict
    (
        IOobject
        (
            "binsMethod_"+fieldName_+"_"+regionName_,
            time_.time().timeName(),
            "uniform",
            time_.time(),
            IOobject::READ_IF_PRESENT,
            IOobject::NO_WRITE,
            false
        )
    );

    dict.readIfPresent("mols", mols_);
    dict.readIfPresent("mass", mass_);
    dict.readIfPresent("mcc", mcc_);
    dict.readIfPresent("mom", mom_);
    dict.readIfPresent("UCollected", UCollected_);
    dict.readIfPresent("rotationalEMean", rotationalEMean_);
    dict.readIfPresent("rotationalDofMean", rotationalDofMean_);
    
    dict.readIfPresent("muu", muu_);    
    dict.readIfPresent("muv", muv_);  
    dict.readIfPresent("muw", muw_);  
    dict.readIfPresent("mvv", mvv_);  
    dict.readIfPresent("mvw", mvw_);  
    dict.readIfPresent("mww", mww_);  

    dict.readIfPresent("mccu", mccu_);  
    dict.readIfPresent("mccv", mccv_);  
    dict.readIfPresent("mccw", mccw_);  
    dict.readIfPresent("eu", eu_);  
    dict.readIfPresent("ev", ev_);      
    dict.readIfPresent("ew", ew_);      
    dict.readIfPresent("e", e_);     
    
    dict.readIfPresent("averagingCounter", averagingCounter_);
    
    Info << "Some properties read in: "
         << "mols = " << mols_[0] 
         << ", mass = " << mass_[0]
         << ", averagingCounter = " << averagingCounter_
         << endl;
}

void dsmcBinsMethod::writeOut()
{
    if (time_.time().outputTime())
    {
        IOdictionary dict
        (
            IOobject
            (
                "binsMethod_"+fieldName_+"_"+regionName_,
                time_.time().timeName(),
                "uniform",
                time_.time(),
                IOobject::NO_READ,
                IOobject::NO_WRITE,
                false
            )
        );

        dict.add("mols", mols_);
        dict.add("mass", mass_);
        dict.add("mcc", mcc_);
        dict.add("mom", mom_);
        dict.add("UCollected", UCollected_);
        dict.add("rotationalEMean", rotationalEMean_);
        dict.add("rotationalDofMean", rotationalDofMean_);
        
        dict.add("muu", muu_);    
        dict.add("muv", muv_);  
        dict.add("muw", muw_);  
        dict.add("mvv", mvv_);  
        dict.add("mvw", mvw_);  
        dict.add("mww", mww_);  

        dict.add("mccu", mccu_);  
        dict.add("mccv", mccv_);  
        dict.add("mccw", mccw_);  
        dict.add("eu", eu_);  
        dict.add("ev", ev_);      
        dict.add("ew", ew_);      
        dict.add("e", e_);
        
        dict.add("averagingCounter", averagingCounter_);
        
        IOstream::streamFormat fmt = time_.time().writeFormat();
        IOstream::versionNumber ver = time_.time().writeVersion();
        IOstream::compressionType cmp = time_.time().writeCompression();
    
        dict.regIOobject::writeObject(fmt, ver, cmp);
        
        Info<< "Some properties written out: "
            << "mols = " << mols_[0]
            << ", mass = " << mass_[0]
            << ", averagingCounter = " << averagingCounter_
            << endl;
    }
}

void dsmcBinsMethod::createField()
{}


void dsmcBinsMethod::calculateField()
{
    averagingCounter_ += 1.0;

    scalarField mass(nBins_, 0.0);
    scalarField mols(nBins_, 0.0);
    scalarField mcc(nBins_, 0.0);
    vectorField mom(nBins_, vector::zero);
    vectorField UCollected(nBins_, vector::zero);
    scalarField rotationalEMean(nBins_, 0.0);
    scalarField rotationalDofMean (nBins_, 0.0);

    scalarField muu(nBins_, 0.0);
    scalarField muv(nBins_, 0.0);
    scalarField muw(nBins_, 0.0);
    scalarField mvv(nBins_, 0.0);
    scalarField mvw(nBins_, 0.0);
    scalarField mww (nBins_, 0.0);
    scalarField mccu (nBins_, 0.0);
    scalarField mccv (nBins_, 0.0);
    scalarField mccw (nBins_, 0.0);

    scalarField eu (nBins_, 0.0);
    scalarField ev (nBins_, 0.0);
    scalarField ew (nBins_, 0.0);
    scalarField e (nBins_, 0.0);     
    
    
    const List< DynamicList<dsmcParcel*> >& cellOccupancy
            = cloud_.cellOccupancy();
            
    const labelList& cells = mesh_.cellZones()[regionId_];

    forAll(cells, c)
    {
        const label& cellI = cells[c];
        
        const List<dsmcParcel*>& molsInCell = cellOccupancy[cellI];

        forAll(molsInCell, mIC)
        {
            dsmcParcel* p = molsInCell[mIC];

            const vector& rI = p->position();

            label n = binModel_->isPointWithinBin(rI, cellI);

            if(n != -1)
            {
                if(findIndex(typeIds_, p->typeId()) != -1)
                {
                    const dsmcParcel::constantProperties& constProp 
                                    = cloud_.constProps(p->typeId());
                                    
                    const scalar& rotationalDof = 
                        cloud_.constProps(p->typeId()).rotationalDegreesOfFreedom();
                        
                    const scalar& massI = constProp.mass();

                    mols[n] += 1.0;
                    mass[n] += massI;
                    mcc[n] += massI*mag(p->U())*mag(p->U());                   
                    UCollected[n] += p->U();
                    mom[n] += massI*p->U();
                    rotationalEMean[n] += p->ERot();
                    rotationalDofMean[n] += rotationalDof;
                    
                    muu[n] += massI*sqr(p->U().x());
                    muv[n] += massI*( (p->U().x()) * (p->U().y()) );
                    muw[n] += massI*( (p->U().x()) * (p->U().z()) );
                    mvv[n] += massI*sqr(p->U().y());
                    mvw[n] += massI*( (p->U().y()) * (p->U().z()) );
                    mww[n] += massI*sqr(p->U().z());
                    mccu[n] += massI*mag(p->U())*mag(p->U())*(p->U().x());
                    mccv[n] += massI*mag(p->U())*mag(p->U())*(p->U().y());
                    mccw[n] += massI*mag(p->U())*mag(p->U())*(p->U().z());

                    eu[n] += cloud_.nParticle()*( p->ERot() + p->EVib() )*(p->U().x());
                    ev[n] += cloud_.nParticle()*( p->ERot() + p->EVib() )*(p->U().y());
                    ew[n] += cloud_.nParticle()*( p->ERot() + p->EVib() )*(p->U().z());
                    e[n] += cloud_.nParticle()*( p->ERot() + p->EVib() );
                }
            }
        }
    }
    

    if(Pstream::parRun())
    {
        forAll(mols, n)
        {
            reduce(mols[n], sumOp<scalar>());
            reduce(mass[n], sumOp<scalar>());
            reduce(mcc[n], sumOp<scalar>());
            reduce(mom[n], sumOp<vector>());                
            reduce(UCollected[n], sumOp<vector>());
            reduce(rotationalEMean[n], sumOp<scalar>());
            reduce(rotationalDofMean[n], sumOp<scalar>());
            
            reduce(muu[n], sumOp<scalar>());
            reduce(muv[n], sumOp<scalar>());
            reduce(muw[n], sumOp<scalar>());
            reduce(mvv[n], sumOp<scalar>());
            reduce(mvw[n], sumOp<scalar>());
            reduce(mww[n], sumOp<scalar>());
            reduce(mccu[n], sumOp<scalar>());
            reduce(mccv[n], sumOp<scalar>());
            reduce(mccw[n], sumOp<scalar>());

            reduce(eu[n], sumOp<scalar>());
            reduce(ev[n], sumOp<scalar>());
            reduce(ew[n], sumOp<scalar>());
            reduce(e[n], sumOp<scalar>());
        }
    }
        
    mass_ += mass;
    mols_ += mols;
    mcc_ += mcc;
    mom_ += mom;
    UCollected_ += UCollected;
    rotationalEMean_ += rotationalEMean;
    rotationalDofMean_ += rotationalDofMean;

    muu_ += muu;
    muv_ += muv;
    muw_ += muw;
    mvv_ += mvv;
    mvw_ += mvw;
    mww_ += mww;
    mccu_ += mccu;
    mccv_ += mccv;
    mccw_ += mccw;

    eu_ += eu;
    ev_ += ev;
    ew_ += ew;
    e_ += e;      
 
    runningTime_ += deltaT_;

    if(runningTime_ >= measuringTime_)
    {
        runningTime_ = 0.0;
        
        averageProperties();

        if(time_.resetFieldsAtOutput())
        {
            //- reset fields
            averagingCounter_ = 0.0;
            
            mols_ = 0.0;
            mass_ = 0.0;
            mcc_ = 0.0;
            mom_ = vector::zero;
            UCollected_ = vector::zero;
            rotationalEMean_ = 0.0;
            rotationalDofMean_ = 0.0;
            
            muu_ = 0.0;
            muv_ = 0.0;
            muw_ = 0.0;
            mvv_ = 0.0;
            mvw_ = 0.0;
            mww_ = 0.0;
            scalarPressure_ = 0.0;
            mccu_ = 0.0;
            mccv_ = 0.0;
            mccw_ = 0.0;
            mcc_ = 0.0;
            eu_ = 0.0;
            ev_ = 0.0;
            ew_ = 0.0;
            e_ = 0.0;            
        }
    }
}

void dsmcBinsMethod::averageProperties()
{
    forAll(mols_, n)
    {
        scalar volume = binModel_->binVolume(n);

        N_[n] = mols_[n]/averagingCounter_;
        rhoN_[n] = (mols_[n]*cloud_.nParticle())/(averagingCounter_*volume);
        rhoM_[n] = (mass_[n]*cloud_.nParticle())/(averagingCounter_*volume);
        
        if(mols_[n] > 0.0)
        {
            UMean_[n] = UCollected_[n]/mols_[n];
            
            UCAM_[n] = mom_[n]/mass_[n];
            
            translationalTemperature_[n] = (1.0/(3.0*physicoChemical::k.value()))
                                            *(
                                                ((mcc_[n]/(mols_[n]*cloud_.nParticle())))
                                                - (
                                                    (mass_[n]/(mols_[n]*cloud_.nParticle())
                                                    )*mag(UMean_[n])*mag(UMean_[n]))
                                            );
                                            
            if(rotationalDofMean_[n] > VSMALL)
            {
                scalar rotationalEMean = rotationalEMean_[n] / averagingCounter_;
                scalar rotationalDofMean = rotationalDofMean_[n]/averagingCounter_;

                rotationalTemperature_[n] = (2.0/physicoChemical::k.value())*(rotationalEMean/rotationalDofMean);
            }
            else
            {
                rotationalTemperature_[n] = 0.0;
            }

            tensorField p(nBins_, tensor::zero);

            p[n].xx() = rhoN_[n]*( muu_[n]/(mols_[n]*cloud_.nParticle()) - ((mass_[n]/(mols_[n]*cloud_.nParticle()))*UMean_[n].x()*UMean_[n].x()) );
            p[n].xy() = rhoN_[n]*( muv_[n]/(mols_[n]*cloud_.nParticle()) - ((mass_[n]/(mols_[n]*cloud_.nParticle()))*UMean_[n].x()*UMean_[n].y()) );
            p[n].xz() = rhoN_[n]*( muw_[n]/(mols_[n]*cloud_.nParticle()) - ((mass_[n]/(mols_[n]*cloud_.nParticle()))*UMean_[n].x()*UMean_[n].z()) );
            p[n].yx() = p[n].xy();
            p[n].yy() = rhoN_[n]*( mvv_[n]/(mols_[n]*cloud_.nParticle()) - ((mass_[n]/(mols_[n]*cloud_.nParticle()))*UMean_[n].y()*UMean_[n].y()) );
            p[n].yz() = rhoN_[n]*( mvw_[n]/(mols_[n]*cloud_.nParticle()) - ((mass_[n]/(mols_[n]*cloud_.nParticle()))*UMean_[n].y()*UMean_[n].z()) );
            p[n].zx() = p[n].xz();
            p[n].zy() = p[n].yz();
            p[n].zz() = rhoN_[n]*(mww_[n]/(mols_[n]*cloud_.nParticle()) - ((mass_[n]/(mols_[n]*cloud_.nParticle()))*UMean_[n].z()*UMean_[n].z()));
            
            pField_[n] = p[n];

            scalarPressure_[n] = (1.0/3.0)*(p[n].xx() + p[n].yy() + p[n].zz());
                                    
            // make reference 
            tensorField tau(nBins_, tensor::zero); 
            
            tau[n] = -p[n];
            tau[n].xx() += scalarPressure_[n];
            tau[n].yy() += scalarPressure_[n];
            tau[n].zz() += scalarPressure_[n];
            tauField_[n] = tau[n];
            
            vectorField q(nBins_, vector::zero);
            
            q[n].x() = rhoN_[n]*(
                                    0.5*(mccu_[n]/(mols_[n]*cloud_.nParticle()))
                                    - 0.5*(mcc_[n]/(mols_[n]*cloud_.nParticle()))*UMean_[n].x()
                                    + eu_[n]/(mols_[n]*cloud_.nParticle())
                                    - (e_[n]/(mols_[n]*cloud_.nParticle()))*UMean_[n].x()
                                )
                                    - p[n].xx()*UMean_[n].x()
                                    - p[n].xy()*UMean_[n].y()
                                    - p[n].xz()*UMean_[n].z();
                                    
                //terms involving pressure tensor should not be multiplied by the number density (see Bird corrigendum)
            
            
            q[n].y() = rhoN_[n]*(
                                    0.5*(mccv_[n]/(mols_[n]*cloud_.nParticle()))
                                    - 0.5*(mcc_[n]/(mols_[n]*cloud_.nParticle()))*UMean_[n].y()
                                    + ev_[n]/(mols_[n]*cloud_.nParticle())
                                    - (e_[n]/(mols_[n]*cloud_.nParticle()))*UMean_[n].y()
                                )
                                    - p[n].yx()*UMean_[n].x()
                                    - p[n].yy()*UMean_[n].y()
                                    - p[n].yz()*UMean_[n].z();
            
            q[n].z() = rhoN_[n]*(
                                    0.5*(mccw_[n]/(mols_[n]*cloud_.nParticle()))
                                    - 0.5*(mcc_[n]/(mols_[n]*cloud_.nParticle()))*UMean_[n].z()
                                    + ew_[n]/(mols_[n]*cloud_.nParticle())
                                    - (e_[n]/(mols_[n]*cloud_.nParticle()))*UMean_[n].z()
                                )
                                    - p[n].zx()*UMean_[n].x()
                                    - p[n].zy()*UMean_[n].y()
                                    - p[n].zz()*UMean_[n].z();
            
            qField_[n] = q[n];
            

        }
    }
}

void dsmcBinsMethod::writeField()
{
    const Time& runTime = time_.time();

    if(runTime.outputTime())
    {
        writeOut();
        
        if(Pstream::master())
        {
//             fileName timePath(runTime.path()/runTime.timeName()/"uniform");

            scalarField bins = binModel_->binPositions();
            vectorField vectorBins = binModel_->bins();

            // output densities
            if(outputField_[0])
            {
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_N.xy",
                    bins,
                    N_
                );
    
//                 writeTimeData
//                 (
//                     timePath_,
//                     "bins_OneDim_"+regionName_+"_"+fieldName_+"_N_3D_pos.xy",
//                     vectorBins,
//                     N_
//                 );
//     
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_rhoN.xy",
                    bins,
                    rhoN_
                );
    
//                 writeTimeData
//                 (
//                     timePath_,
//                     "bins_OneDim_"+regionName_+"_"+fieldName_+"_rhoN_3D_pos.xy",
//                     vectorBins,
//                     rhoN_
//                 );
    
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_rhoM.xy",
                    bins,
                    rhoM_
                );
    
//                 writeTimeData
//                 (
//                     timePath_,
//                     "bins_OneDim_"+regionName_+"_"+fieldName_+"_rhoM_3D_pos.xy",
//                     vectorBins,
//                     rhoM_
//                 );
            }

            // output velocities
            if(outputField_[1])
            {
                
                
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_U_SAM.xyz",
                    bins,
                    UMean_
                );
    
//                 writeTimeData
//                 (
//                     timePath_,
//                     "bins_OneDim_"+regionName_+"_"+fieldName_+"_U_SAM_3D_pos.xyz",
//                     vectorBins,
//                     UMean_
//                 );    

                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_U_CAM.xyz",
                    bins,
                    UCAM_
                );
    
/*                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_U_CAM_3D_pos.xyz",
                    vectorBins,
                    UCAM_
                );*/   
            }

            // output temperature
            if(outputField_[2])
            {
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_translationalTemperature.xy",
                    bins,
                    translationalTemperature_
                );
                
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_rotationalTemperature.xy",
                    bins,
                    rotationalTemperature_
                );
                
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_vibrationalTemperature.xy",
                    bins,
                    vibrationalTemperature_
                );
                
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_overallTemperature.xy",
                    bins,
                    overallTemperature_
                );
                
//                 writeTimeData
//                 (
//                     timePath_,
//                     "bins_OneDim_"+regionName_+"_"+fieldName_+"_T.xy",
//                     bins,
//                     T_
//                 );
//     
//                 writeTimeData
//                 (
//                     timePath_,
//                     "bins_OneDim_"+regionName_+"_"+fieldName_+"_T_3D_pos.xy",
//                     vectorBins,
//                     T_
//                 );  
            }

            // output pressure
            if(outputField_[3])
            {
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_pressureTensor.xyz",
                    bins,
                    pField_
                );
    
//                 writeTimeData
//                 (
//                     timePath_,
//                     "bins_OneDim_"+regionName_+"_"+fieldName_+"_pressureTensor_3D_pos.xyz",
//                     vectorBins,
//                     pField_
//                 );

                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_p.xy",
                    bins,
                    scalarPressure_
                );

                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_stressTensor.xyz",
                    bins,
                    tauField_
                );
                
                writeTimeData
                (
                    timePath_,
                    "bins_OneDim_"+regionName_+"_"+fieldName_+"_heatFluxVector.xyz",
                    bins,
                    qField_
                );                
            }
        }
    }
}

void dsmcBinsMethod::updateProperties(const dictionary& newDict)
{
    //- the main properties should be updated first
    updateBasicFieldProperties(newDict);

}


} // End namespace Foam

// ************************************************************************* //
